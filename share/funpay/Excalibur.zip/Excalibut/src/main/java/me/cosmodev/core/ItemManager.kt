package me.cosmodev.core

import me.cosmodev.Plugin
import org.bukkit.ChatColor
import org.bukkit.Material
import org.bukkit.enchantments.Enchantment
import org.bukkit.inventory.ItemStack

object ItemManager {

    private var cachedExcalibur: ItemStack? = null

    fun createExcalibur(): ItemStack {
        val pluginConfig = Plugin.getInstance()?.config
        val material = Material.DIAMOND_SWORD

        val exab = ItemStack(material, 1)
        val itemMeta = exab.itemMeta

        itemMeta?.let {
            it.displayName = ChatColor.translateAlternateColorCodes('&', pluginConfig?.getString("excalibur_name") ?: "&6Экскалибур")
            it.addEnchant(Enchantment.DAMAGE_ALL, 18, true)
            it.addEnchant(Enchantment.VANISHING_CURSE, 1, true)
            it.isUnbreakable = true
            exab.itemMeta = it
        }

        return exab
    }

    fun getExcalibur(): ItemStack? {
        if (cachedExcalibur == null) {
            cachedExcalibur = createExcalibur()
        }
        return cachedExcalibur?.clone()
    }

    fun getExcaliburGivenMessage(): String {
        val pluginConfig = Plugin.getInstance()?.config
        return ChatColor.translateAlternateColorCodes('&', pluginConfig?.getString("messages.excalibur_given") ?: "&aВы получили экскалибур, теперь вы обезьяна с гранатой!")
    }

    fun isExcalibur(item: ItemStack): Boolean {
        val excalibur = getExcalibur()
        return item.isSimilar(excalibur)
    }
}