package me.cosmodev

import me.cosmodev.core.ItemManager
import org.bukkit.Bukkit
import org.bukkit.ChatColor
import org.bukkit.command.Command
import org.bukkit.command.CommandSender
import org.bukkit.entity.Entity
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.event.entity.PlayerDeathEvent
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.event.player.PlayerDropItemEvent
import org.bukkit.event.player.PlayerJoinEvent
import org.bukkit.plugin.java.JavaPlugin
import java.time.Duration
import java.time.Instant
import java.util.*

class Plugin : JavaPlugin(), Listener {

    private var isRunning = false
    private var currentOwner: String? = null
    private val owners: MutableMap<String, Long> = HashMap()

    override fun onEnable() {
        instance = this
        saveDefaultConfig()
        server.pluginManager.registerEvents(this, this)
    }

    override fun onCommand(sender: CommandSender, command: Command, label: String, args: Array<String>): Boolean {
        if (label.equals("forceexcalibur", ignoreCase = true) && sender is Player && sender.hasPermission("excalibur.forceexcalibur")) {
            if (isRunning) {
                sender.sendMessage("Ивент Excalibur уже запущен.")
            } else {
                val onlinePlayers = Bukkit.getOnlinePlayers()
                if (onlinePlayers.isNotEmpty()) {
                    val randomPlayer = onlinePlayers.random()
                    giveExcaliburToPlayer(randomPlayer)
                } else {
                    sender.sendMessage("Нет онлайн игроков для выдачи меча Excalibur.")
                }
            }
            return true
        } else if (label.equals("excalibur", ignoreCase = true) && sender is Player && sender.hasPermission("excalibur.info")) {
            val owner = currentOwner
            if (owner != null) {
                sender.sendMessage(getOwnerDisplayMessage(owner))
            } else {
                sender.sendMessage("Ивент не запущен.")
            }
            return true
        }

        return false
    }

    @EventHandler
    fun onPlayerJoin(e: PlayerJoinEvent) {
        if (Bukkit.getOnlinePlayers().size >= 50 && !isRunning) {
            val randomPlayer = Bukkit.getOnlinePlayers().random()
            giveExcaliburToPlayer(randomPlayer)
        }
    }

    @EventHandler
    fun onInventoryClick(event: InventoryClickEvent) {
        val clickedItem = event.currentItem ?: return
        if (ItemManager.isExcalibur(clickedItem)) {
            event.isCancelled = true
        }
    }

    @EventHandler
    fun onPlayerDeath(event: PlayerDeathEvent) {
        val player = event.entity
        val killer = event.entity.killer

        if (killer is Player) {
            if (player.inventory.contains(ItemManager.getExcalibur())) {
                giveExcaliburToPlayer(killer)
            }
        } else {
            if(player.inventory.contains(ItemManager.getExcalibur())){
                checkPlayerAndGiveExcalibur(player.name)
            }
        }
    }

    private fun forceExcaliburEvent(player: Player) {
        val onlinePlayers = Bukkit.getOnlinePlayers()
        if (onlinePlayers.isNotEmpty() && !isRunning) {
            val randomPlayer = onlinePlayers.random()
            giveExcaliburToPlayer(randomPlayer)
        }
    }

    @EventHandler
    fun onPlayerJoinCheckActivity(e: PlayerJoinEvent) {
        val player = e.player
        if (currentOwner != null && player.name == currentOwner && Duration.between(Instant.ofEpochSecond(owners[currentOwner] ?: Instant.now().epochSecond), Instant.now()).toDays() >= 2) {
            val onlinePlayers = Bukkit.getOnlinePlayers().filter { it.name != currentOwner }
            if (onlinePlayers.isNotEmpty()) {
                val newOwner = onlinePlayers.random()
                giveExcaliburToPlayer(newOwner)
            }
        }
    }

    @EventHandler
    fun onPlayerDropItem(e: PlayerDropItemEvent) {
        val item = e.itemDrop.itemStack
        if (ItemManager.isExcalibur(item)) {
            e.isCancelled = true
            e.player.sendMessage(getCantDropMessage())
        }
    }


    private fun checkPlayerAndGiveExcalibur(playerName: String) {
        val player = Bukkit.getPlayerExact(playerName)
        if (player != null && player.isOnline && !player.isDead) {
            giveExcaliburToPlayer(player)
        } else {
            Bukkit.getScheduler().runTaskLater(this, {
                checkPlayerAndGiveExcalibur(playerName)
            }, 100)
        }
    }



    companion object {
        private var instance: Plugin? = null

        fun getInstance(): Plugin? {
            return instance
        }
    }

    fun getOwnerDisplayMessage(player: String): String {
        return ChatColor.translateAlternateColorCodes('&', getConfig().getString("messages.owner_display") ?: "Текущий владелец меча: %player%")
            .replace("%player%", player)
    }

    fun getCantDropMessage(): String {
        return ChatColor.translateAlternateColorCodes('&', getConfig().getString("messages.cant_drop") ?: "Нельзя выкидывать меч")
    }

    private fun giveExcaliburToPlayer(player: Player) {
        val excalibur = ItemManager.getExcalibur()
        if (excalibur != null) {
            player.inventory.addItem(excalibur)
            currentOwner = player.name
            owners[currentOwner!!] = Instant.now().epochSecond
            isRunning = true
            player.sendMessage(ItemManager.getExcaliburGivenMessage())
            Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', config.getString("messages.global_excalibur_message") ?: "&cСообщения не настроенны!").replace("%player%", player.name))
        } else {
            logger.warning("Ошибка при получении экскалибура.")
        }
    }
}
