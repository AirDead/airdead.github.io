package me.cosmodev

import me.cosmodev.core.ItemManager
import org.bukkit.Bukkit
import org.bukkit.ChatColor
import org.bukkit.command.Command
import org.bukkit.command.CommandSender
import org.bukkit.entity.Entity
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.event.entity.PlayerDeathEvent
import org.bukkit.event.player.PlayerJoinEvent
import org.bukkit.plugin.java.JavaPlugin
import java.time.Duration
import java.time.Instant
import java.util.*

class Plugin : JavaPlugin(), Listener {

    private var isRunning: Boolean = false
    private var currentOwner: String? = null
    private val owners: MutableMap<String, Long> = HashMap()

    override fun onEnable() {
        instance = this
        saveDefaultConfig()
        server.pluginManager.registerEvents(this, this)
    }

    override fun onCommand(sender: CommandSender, command: Command, label: String, args: Array<String>): Boolean {
        if (label.equals("forceexcalibur", ignoreCase = true) && sender is Player && sender.hasPermission("excalibur.forceexcalibur")) {
            forceExcaliburEvent(sender)
            return true
        }
        return false
    }

    @EventHandler
    fun onPlayerJoin(e: PlayerJoinEvent) {
        if (Bukkit.getOnlinePlayers().size >= 50 && !isRunning) {
            val randomPlayer = Bukkit.getOnlinePlayers().random()
            giveExcaliburToPlayer(randomPlayer)
        }
    }

    @EventHandler
    fun onPlayerDeath(e: PlayerDeathEvent) {
        val player: Player = e.entity
        val cause = player.lastDamageCause

        if (cause !is EntityDamageByEntityEvent) {
            checkPlayerAndGiveExcalibur(player.name)
        } else {
            val damager: Entity? = cause.damager
            if (damager is Player && player.inventory.contains(ItemManager.getExcalibur())) {
                giveExcaliburToPlayer(damager)
            }
        }

        if (player.name == currentOwner) {
            val killer = player.killer?.name ?: "Unknown"
            Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', config.getString("messages.excalibur_owner_died") ?: "&cСообщения не настроенны!").replace("%killer%", killer).replace("%killed%", player.name))
        }
    }

    @EventHandler
    fun onPlayerKill(e: EntityDamageByEntityEvent) {
        val damaged = e.entity
        val damager = e.damager
        if (damager is Player && damaged is Player && damager.inventory.contains(ItemManager.getExcalibur())) {
            giveExcaliburToPlayer(damager)
        }
    }

    private fun forceExcaliburEvent(player: Player) {
        val onlinePlayers = Bukkit.getOnlinePlayers()
        if (onlinePlayers.isNotEmpty() && !isRunning) {
            val randomPlayer = onlinePlayers.random()
            giveExcaliburToPlayer(randomPlayer)
        }
    }

    private fun giveExcaliburToPlayer(player: Player) {
        val excalibur = ItemManager.getExcalibur()
        if (excalibur != null) {
            player.inventory.addItem(excalibur)
            currentOwner = player.name
            owners[currentOwner!!] = Instant.now().epochSecond
            isRunning = true
            player.sendMessage(ItemManager.getExcaliburGivenMessage())
        } else {
            logger.warning("Ошибка при получении экскалибура.")
        }
    }

    @EventHandler
    fun onPlayerJoinCheckActivity(e: PlayerJoinEvent) {
        val player = e.player
        if (currentOwner != null && player.name == currentOwner && Duration.between(Instant.ofEpochSecond(owners[currentOwner]!!), Instant.now()).toDays() >= 2) {
            val onlinePlayers = Bukkit.getOnlinePlayers().filter { it.name != currentOwner }
            if (onlinePlayers.isNotEmpty()) {
                val newOwner = onlinePlayers.random()
                giveExcaliburToPlayer(newOwner)
            }
        }
    }

    private fun checkPlayerAndGiveExcalibur(playerName: String) {
        val player = Bukkit.getPlayerExact(playerName)
        if (player != null && player.isOnline) {
            giveExcaliburToPlayer(player)
        } else {
            Bukkit.getScheduler().runTaskLater(this, {
                checkPlayerAndGiveExcalibur(playerName)
            }, 100)
        }
    }


    companion object {
        private var instance: Plugin? = null

        fun getInstance(): Plugin? {
            return instance
        }
    }
}
