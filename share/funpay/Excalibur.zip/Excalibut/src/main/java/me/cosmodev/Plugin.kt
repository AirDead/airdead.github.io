package me.cosmodev

import me.cosmodev.core.ItemManager
import org.bukkit.Bukkit
import org.bukkit.ChatColor
import org.bukkit.command.Command
import org.bukkit.command.CommandSender
import org.bukkit.entity.Entity
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.event.entity.PlayerDeathEvent
import org.bukkit.event.player.PlayerDropItemEvent
import org.bukkit.event.player.PlayerJoinEvent
import org.bukkit.plugin.java.JavaPlugin
import java.time.Duration
import java.time.Instant
import java.util.*

class Plugin : JavaPlugin(), Listener {

    private var isRunning = false
    private var currentOwner: String? = null
    private val owners: MutableMap<String, Long> = HashMap()

    override fun onEnable() {
        instance = this
        saveDefaultConfig()
        server.pluginManager.registerEvents(this, this)
    }

    override fun onCommand(sender: CommandSender, command: Command, label: String, args: Array<String>): Boolean {
        if (label.equals("forceexcalibur", ignoreCase = true) && sender is Player && sender.hasPermission("excalibur.forceexcalibur")) {
            val onlinePlayers = Bukkit.getOnlinePlayers()
            if (onlinePlayers.isNotEmpty()) {
                val randomPlayer = onlinePlayers.random()
                giveExcaliburToPlayer(randomPlayer)
            } else {
                sender.sendMessage("Нет онлайн игроков для выдачи меча Excalibur.")
            }
            return true
        } else if (label.equals("excalibur", ignoreCase = true) && sender is Player && sender.hasPermission("excalibur.info")) {
            val owner = currentOwner
            if (owner != null) {
                sender.sendMessage(getOwnerDisplayMessage(owner))
            } else {
                sender.sendMessage("Ивент не запущен.")
            }
            return true
        }

        return false
    }

    @EventHandler
    fun onPlayerJoin(e: PlayerJoinEvent) {
        if (Bukkit.getOnlinePlayers().size >= 50 && !isRunning) {
            val randomPlayer = Bukkit.getOnlinePlayers().random()
            giveExcaliburToPlayer(randomPlayer)
        }
    }

    @EventHandler
    fun onPlayerDeath(e: PlayerDeathEvent) {
        val player: Player = e.entity
        val cause = player.lastDamageCause

        if (cause !is EntityDamageByEntityEvent) {
            checkPlayerAndGiveExcalibur(player.name)
        } else {
            val damager: Entity? = cause.damager
            if (damager is Player && player.inventory.contains(ItemManager.getExcalibur())) {
                giveExcaliburToPlayer(damager)
                Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', config.getString("messages.excalibur_owner_died") ?: "&cСообщения не настроенны!").replace("%killer%", damager.name).replace("%killed%", player.name))
            }
        }
    }

    @EventHandler
    fun onPlayerKill(e: EntityDamageByEntityEvent) {
        val damaged = e.entity
        val damager = e.damager
        if (damager is Player && damaged is Player && damager.inventory.contains(ItemManager.getExcalibur())) {
            giveExcaliburToPlayer(damager)
        }
    }

    private fun forceExcaliburEvent(player: Player) {
        val onlinePlayers = Bukkit.getOnlinePlayers()
        if (onlinePlayers.isNotEmpty() && !isRunning) {
            val randomPlayer = onlinePlayers.random()
            giveExcaliburToPlayer(randomPlayer)
        }
    }

    @EventHandler
    fun onPlayerJoinCheckActivity(e: PlayerJoinEvent) {
        val player = e.player
        if (currentOwner != null && player.name == currentOwner && Duration.between(Instant.ofEpochSecond(owners[currentOwner] ?: Instant.now().epochSecond), Instant.now()).toDays() >= 2) {
            val onlinePlayers = Bukkit.getOnlinePlayers().filter { it.name != currentOwner }
            if (onlinePlayers.isNotEmpty()) {
                val newOwner = onlinePlayers.random()
                giveExcaliburToPlayer(newOwner)
            }
        }
    }

    @EventHandler
    fun onPlayerDropItem(e: PlayerDropItemEvent) {
        val item = e.itemDrop.itemStack
        if (ItemManager.isExcalibur(item)) {
            e.isCancelled = true
            e.player.sendMessage(getCantDropMessage())
        }
    }


    private fun checkPlayerAndGiveExcalibur(playerName: String) {
        val player = Bukkit.getPlayerExact(playerName)
        if (player != null && player.isOnline) {
            giveExcaliburToPlayer(player)
        } else {
            Bukkit.getScheduler().runTaskLater(this, {
                checkPlayerAndGiveExcalibur(playerName)
            }, 100)
        }
    }



    companion object {
        private var instance: Plugin? = null

        fun getInstance(): Plugin? {
            return instance
        }
    }

    fun getOwnerDisplayMessage(player: String): String {
        return ChatColor.translateAlternateColorCodes('&', getConfig().getString("messages.owner_display") ?: "Текущий владелец меча: %player%")
            .replace("%player%", player)
    }

    fun getCantDropMessage(): String {
        return ChatColor.translateAlternateColorCodes('&', getConfig().getString("messages.cant_drop") ?: "Нельзя выкидывать меч")
    }

    private fun giveExcaliburToPlayer(player: Player) {
        val excalibur = ItemManager.getExcalibur()
        if (excalibur != null) {
            player.inventory.addItem(excalibur)
            currentOwner = player.name
            owners[currentOwner!!] = Instant.now().epochSecond
            isRunning = true
            player.sendMessage(ItemManager.getExcaliburGivenMessage())
            Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', config.getString("messages.global_excalibur_message") ?: "&cСообщения не настроенны!").replace("%player%", player.name))
        } else {
            logger.warning("Ошибка при получении экскалибура.")
        }
    }
}
